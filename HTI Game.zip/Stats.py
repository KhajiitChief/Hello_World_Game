class Stat():
    int = 1
    dex = 1
    eva = 1
    stgh = 1