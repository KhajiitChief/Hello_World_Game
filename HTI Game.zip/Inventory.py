class Inventory():
    def __init__(self):
        self.items = {}

    def append(self, item):
        self.items[item.name] = item

    #remove item from inventory
    def remove(self):pass

    def __str__(self):
        print("""-----------------------------------
***         |Inventory|         ***
-----------------------------------""")
        out = '\t'.join(["Name    ", "        Use"])
        for item in self.items.values():
            out += '\n' + '\t'.join([str(c) for c in [item.name, "   ", item.use, "(", item.clss, ")"]])
        return out


class Items():
    name = "name"
    use = "use"
    attack = 0
    armor = 0
    defense = 0

    def __init__(self, **kwargs):
        self.name = kwargs['name'] if 'name' in kwargs else "item"
        self.use = kwargs['use'] if 'use' in kwargs else "This Item Has no Use..."
        self.attack = kwargs['attack'] if 'attack' in kwargs else "   "
        self.armor = kwargs['protection'] if 'protection' in kwargs else "   "
        self.defense = kwargs['block'] if 'block' in kwargs else "   "


inventory = Inventory()
leather_armour = Items(name= "Leather Armour", protection= .05, use= "Crappy Deflection Protection")
chain_mail = Items(name= "Chain Mail", protection= .20, use= "Meh Deflection Protection")
iron_armour = Items(name= "Iron Armour", protection= .30, use= "OK Deflection Protection")
steel_armour = Items(name= "Steel Armour", protection= .45, use= "Pretty Good Deflection Protection")
special_armour = Items(name= "Ridiculous Armour", protection= .65, use= "OP Deflection Protection")

Wood_shield = Items(name= "Wood Shield   ", block= .05, use= "Battle Protection", clss= "battle")
Hide_shield = Items(name= "Hide Shield", block= .08)
Iron_shield = Items(name= "Iron Shield", block= .10)
Steel_shield = Items(block= .25)
Special_shield = Items(block= .5)

wood_sword = Items(name="Wood Sword    ", attack= 5, block= .01, use= "Stabby Stabby")
stone_sword = Items(name="Stone Sword   ", attack= 10)
iron_sword = Items(name="Iron Sword    ", attack= 15, block= .025, use= "Stabby Stabby", clss= "battle")
steel_sword = Items(name="Steel Sword   ", attack= 25)
special_sword = Items(name="Special Sword ", attack= 40)

gold = Items()